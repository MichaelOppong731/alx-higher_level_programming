# 0x09. Python - Everything is object

These projects are about response tricky answers of Python code.

## Tasks:

Exist two types of tasks in this project:

- Mandatory

- Advanced

### Mandatory

Note:Write the name of the function in the file, without ().

- 0-answer.txt &rarr; What function would you use to print the type of an object?

- 1-answer.txt &rarr; How do you get the variable identifier (which is the memory address in the CPython implementation)?

- 2-answer.txt &rarr; a and b point to the same object?

- 3-answer.txt &rarr; a and b point to the same object?

- 4-answer.txt &rarr; a and b point to the same object?

- 5-answer.txt &rarr; a and b point to the same object?

- 6-answer.txt &rarr; What do these 3 lines print?

- 7-answer.txt &rarr; What do these 3 lines print?

- 8-answer.txt &rarr; What do these 3 lines print?

- 9-answer.txt &rarr; What do these 3 lines print?

- 10-answer.txt &rarr; What do these 3 lines print?

- 11-answer.txt &rarr; What do these 3 lines print?

- 12-answer.txt &rarr; What do these 3 lines print?

- 13-answer.txt &rarr; What do these 3 lines print?

- 14-answer.txt &rarr; What does this script print?

- 15-answer.txt &rarr; What does this script print?

- 16-answer.txt &rarr; What does this script print?

- 17-answer.txt &rarr; What does this script print?

- 18-answer.txt &rarr; What does this script print?

- 19-copy_list.py &rarr; Write a function def copy_list(l): that returns a copy of a list.

- 20-answer.txt &rarr; Is a a tuple?

- 21-answer.txt &rarr; Is a a tuple?

- 22-answer.txt &rarr; Is a a tuple?

- 23-answer.txt &rarr; Is a a tuple?

- 24-answer.txt &rarr; What does this script print?

- 25-answer.txt &rarr; What does this script print?

- 26-answer.txt &rarr; What does this script print?

- 27-answer.txt &rarr; Will the last line of this script print 139926795932424?

- 28-answer.txt &rarr; Will the last line of this script print 139926795932424?

### Advanced

- #pythonic &rarr; Write a function magic_string() that returns a string “BestSchool” n times the number of the iteration.

- 101-locked_class.py &rarr; Write a class LockedClass with no class or object attribute, that prevents the user from dynamically creating new instance attributes, except if the new instance attribute is called first_name.

- 103-line[1, 2].txt &rarr; CPython: int 1/3

- 104-line[1, 2, 3, 4, 5].txt &rarr; CPython: int 2/3

- 105-line1.txt &rarr; CPython: int 3/3

- 106-line[1, 2, 3, 4, 5].txt &rarr; CPython: Clear strings
