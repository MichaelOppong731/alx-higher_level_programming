#!/usr/bin/python3
def copy_list(src_list):
    return list(src_list)
